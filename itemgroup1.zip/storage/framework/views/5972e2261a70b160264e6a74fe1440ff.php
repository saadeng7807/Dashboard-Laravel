

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-12">
            <h1 class="alert alert-success text-center">بيانات الأصناف</h1>
            <div class="card">
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>رقم العنصر </th>
                                <th>اسم العنصر</th>
                                <th>اسم المجموعة</th>
                                <th>السعر</th>
                                <th>الكمية</th>
                                <th>اللون</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if($data!=null): ?>
                         
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <tr>
                            <td><?php echo e($row->id); ?></td>
                            <td><?php echo e($row->itemname); ?></td>
                            <td><?php echo e($row->Itemgroupsname); ?></td>
                            <td><?php echo e($row->price); ?></td>
                            <td><?php echo e($row->qty); ?></td>
                            <td><?php echo e($row->price); ?></td>
                        </tr>
                          
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            
            
                       <?php endif; ?>
            
                        </tbody>
                    </table>
                </div>
            </div>
            
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashbaord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\itemgroup\resources\views/dashboard/controlpanel.blade.php ENDPATH**/ ?>