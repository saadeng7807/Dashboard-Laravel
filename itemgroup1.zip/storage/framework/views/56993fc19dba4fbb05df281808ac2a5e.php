<?php $__env->startSection('content'); ?>

<div class="container">

   <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card mt-4">
        <div class="card-body">
            <div class="row ">
                <div class="col-sm-3">
                 <img src="/image/<?php echo e($row->image); ?>" width="150" height="150">
                </div>
                <div class="col-sm-9 text-start">
                 <h1 class="alert alert-info text-dark"><?php echo e($row->itemname); ?></h1>
                 <h5>price : <?php echo e($row->price); ?></h5>

                 <div class="row">
                    <div class="col text-center">
                      <a href="<?php echo e(route('addtocart',['id'=>$row->id])); ?>" class="btn btn-success">Add To Card</a>
                    </div>
                 </div>
                </div>
            </div>
        </div>
    </div>

   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\itemgroup\resources\views/showproduct.blade.php ENDPATH**/ ?>