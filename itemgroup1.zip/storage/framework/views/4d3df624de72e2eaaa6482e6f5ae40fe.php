


<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col">
            <table class="table">
             <thead>
                <tr>
                    <th>name</th>
                    <th>type</th>
                    <th>country</th>
                    <th>logo</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $data['response']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($row['name']); ?></td>
                    <td><?php echo e($row['type']); ?></td>
                    <td><?php echo e($row['country']['name']); ?></td>
                    <td><img src="<?php echo e($row['logo']); ?>" width="100" height="100"></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
             </div>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\itemgroup\resources\views/cafe.blade.php ENDPATH**/ ?>